title: CSS 动画 - 按钮边框动画
date: '2019-11-12 13:49:48'
updated: '2019-11-12 14:01:51'
tags: [html, css, css动画]
permalink: /articles/2019/11/12/1573537788739.html
---
![](https://img.hacpai.com/bing/20191024.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 描述

当鼠标移上时，创建一个边框的动画。

### HTML

```html
<div class="button-border"><button class="button">Submit</button></div>
```

### CSS
```css
.button {
  background-color: #c47135;
  border: none;
  color: #ffffff;
  outline: none;
  padding: 12px 40px 10px;
  position: relative;
}
.button:before,
.button:after {
  border: 0 solid transparent;
  transition: all 0.25s;
  content: '';
  height: 24px;
  position: absolute;
  width: 24px;
}
.button:before {
  border-top: 2px solid #c47135;
  left: 0px;
  top: -5px;
}
.button:after {
  border-bottom: 2px solid #c47135;
  bottom: -5px;
  right: 0px;
}
.button:hover {
  background-color: #c47135;
}
.button:hover:before,
.button:hover:after {
  height: 100%;
  width: 100%;
}

```
### Demo
<iframe id="result-iframe" class="result-iframe " sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-presentation allow-same-origin allow-scripts" allow="geolocation; microphone; camera; midi; vr; accelerometer; gyroscope; payment; ambient-light-sensor; encrypted-media" tabindex="-1" data-src="https://cdpn.io/vanessa219/fullembedgrid/JgpPrb?type=embed&amp;animations=run" src="https://cdpn.io/vanessa219/fullembedgrid/JgpPrb?type=embed&amp;animations=run" allowtransparency="true" frameborder="0" scrolling="yes" allowpaymentrequest="true" allowfullscreen="true" name="CodePen Preview for Button border animation" title="CodePen Preview for Button border animation">
      </iframe>
### 说明

当鼠标移上时，使用 `:before` 和 `:after` 伪元素做为边框以实现动画效果。

### 浏览器支持

支持率：**100%**

---
转载自：https://hacpai.com/article/1565100963387?r=Vanessa
