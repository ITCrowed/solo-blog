title: Python3：定时任务实现方式
date: '2019-11-12 15:59:48'
updated: '2019-11-12 15:59:48'
tags: [python, 定时任务]
permalink: /articles/2019/11/12/1573545588884.html
---
![](https://img.hacpai.com/bing/20181115.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

Python3下实现定时任务的方式有多种方式，简单汇总一下。
## 一、循环sleep：

　最简单的方式，在循环里放入要执行的任务，然后sleep一段时间再执行。缺点是，不容易控制，而且sleep是个阻塞函数

```python
def timer(n):  
    ''''' 
    每n秒执行一次 
    '''  
    while True:    
        print(time.strftime('%Y-%m-%d %X',time.localtime()))    
        yourTask()  # 此处为要执行的任务    
        time.sleep(n)
```

## 二、threading的Timer：

例如：5秒后执行

```python
def printHello(): print("start" )
  Timer(5, printHello).start()
```

例如：间隔5秒执行一次

```python
def printHello():  
    print("start" )
    timer = threading.Timer(5,printHello)
    timer.start()
  
if __name__ == "__main__":  
    printHello()
```
例如：两种方式组合用，5秒钟后执行，并且之后间隔5秒执行一次
```
def printHello():  
    print("start")  
    timer = threading.Timer(5,printHello)
    timer.start()
  
if __name__ == "__main__":  
    timer = threading.Timer(5,printHello)
    timer.start()
```
## 三、sched模块：

　sched是一种调度（延时处理机制）。

```python
import time  
import os  
import sched  
  
  
# 初始化sched模块的scheduler类  
# 第一个参数是一个可以返回时间戳的函数，第二个参数可以在定时未到达之前阻塞。  
schedule = sched.scheduler(time.time, time.sleep)  
  
# 被周期性调度触发的函数  
def execute_command(cmd, inc):  
    print('执行主程序')
    
    ''''' 
    终端上显示当前计算机的连接情况 
    '''  
    os.system(cmd)  
    schedule.enter(inc, 0, execute_command, (cmd, inc))  
  
  
def main(cmd, inc=60):  
    # enter四个参数分别为：间隔事件、优先级（用于同时间到达的两个事件同时执行时定序）、被调用触发的函数，  
    # 给该触发函数的参数（tuple形式）  
    schedule.enter(0, 0, execute_command, (cmd, inc))  
    schedule.run()  
  
  
# 每60秒查看下网络连接情况  
if __name__ == '__main__':  
    main("netstat -an", 60)
```

## 四、定时框架APScheduler：

　APScheduler是基于Quartz的一个Python定时任务框架。提供了基于日期、固定时间间隔以及crontab类型的任务，并且可以持久化任务。

　需要先安装apscheduler库，cmd窗口命令：pip install apscheduler

　简单的间隔时间调度代码：
```python
from datetime import datetime
import time
import os
from apscheduler.schedulers.background import BackgroundScheduler

def tick():
    print('Tick! The time is: %s' % datetime.now())

if __name__ == '__main__':
    scheduler = BackgroundScheduler()
    # 间隔3秒钟执行一次
    scheduler.add_job(tick, 'interval', seconds=3)
    # 这里的调度任务是独立的一个线程
    scheduler.start()
    print('Press Ctrl+{0} to exit'.format('Break' if os.name == 'nt' else 'C'))
    try:
        # 其他任务是独立的线程执行
        while True:
            time.sleep(2)
            print('sleep!')
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
        print('Exit The Job!')
```

## 五、定时框架Celery：

　非常强大的分布式任务调度框架；  
　需要先安装Celery库，cmd窗口命令： pip install Celery

## 六、定时框架RQ：

　基于Redis的作业队列工具，优先选择APScheduler定时框架；

## 七、使用windows的定时任务：

　可以将所需要的Python程序打包成exe文件，然后在windows下设置定时执行。

## 八、Linux的定时任务（Crontab）：

　　在Linux下可以很方便的借助Crontab来设置和运行定时任务。进入Crontab文件编辑页面，设置时间间隔，使用一些shell命令来运行bash脚本或者是Python脚本，保存后Linux会自动按照设定的时间来定时运行程序。




