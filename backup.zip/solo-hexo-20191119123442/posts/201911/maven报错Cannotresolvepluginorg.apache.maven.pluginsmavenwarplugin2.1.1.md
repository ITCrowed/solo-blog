title: maven 报错 Cannot resolve plugin org.apache.maven.plugins:maven-war-plugin:2.1.1
date: '2019-11-17 16:22:10'
updated: '2019-11-17 16:22:10'
tags: [Java, Maven, SpringBoot]
permalink: /articles/2019/11/17/1573978929718.html
---
![](https://img.hacpai.com/bing/20190810.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# maven 报错 Cannot resolve plugin org.apache.maven.plugins:maven-war-plugin:2.1.1（转载）
主要原因是本地maven的配置文件和仓库地址不一致。网上清一片的说maven路径不一致 (但是改了后也无法解决) 👍 
解决办法: 添加镜像源 - 在配置的setting.xml加入:
```
<mirror>
    <!-- 阿里镜像 -->
            <id>alimaven</id>
            <mirrorOf>central</mirrorOf>
            <name>aliyun maven</name>
            <url>http://maven.aliyun.com/nexus/content/repositories/central/</url>
        </mirror>
        <mirror>
            <id>alimaven</id>
            <name>aliyun maven</name>
            <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
            <mirrorOf>central</mirrorOf>
        </mirror>
        <mirror>
            <id>central</id>
            <name>Maven Repository Switchboard</name>
            <url>http://repo1.maven.org/maven2/</url>
            <mirrorOf>central</mirrorOf>
        </mirror>
        <mirror>
            <id>repo2</id>
            <mirrorOf>central</mirrorOf>
            <name>Human Readable Name for this Mirror.</name>
            <url>http://repo2.maven.org/maven2/</url>
        </mirror>
        <mirror>
            <id>ibiblio</id>
            <mirrorOf>central</mirrorOf>
            <name>Human Readable Name for this Mirror.</name>
            <url>http://mirrors.ibiblio.org/pub/mirrors/maven2/</url>
        </mirror>
        <mirror>
            <id>jboss-public-repository-group</id>
            <mirrorOf>central</mirrorOf>
            <name>JBoss Public Repository Group</name>
            <url>http://repository.jboss.org/nexus/content/groups/public</url>
        </mirror>
        <mirror>
            <id>google-maven-central</id>
            <name>Google Maven Central</name>
            <url>https://maven-central.storage.googleapis.com
            </url>
            <mirrorOf>central</mirrorOf>
        </mirror>
        <!-- 中央仓库在中国的镜像 -->
        <mirror>
            <id>maven.net.cn</id>
            <name>oneof the central mirrors in china</name>
            <url>http://maven.net.cn/content/groups/public/</url>
            <mirrorOf>central</mirrorOf>
        </mirror>

```
重新导入maven即可
---
版权声明：本文为CSDN博主「z_子恒」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。  
原文链接：https://blog.csdn.net/weixin_39569611/article/details/99981044
