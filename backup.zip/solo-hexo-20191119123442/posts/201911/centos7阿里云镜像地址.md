title: centos7 阿里云镜像地址
date: '2019-11-15 13:58:42'
updated: '2019-11-15 13:58:42'
tags: [centos]
permalink: /articles/2019/11/15/1573797522194.html
---
![](https://img.hacpai.com/bing/20190102.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

http://mirrors.aliyun.com/centos/7/isos/x86_64/
