title: pandas nan值处理方法
date: '2019-11-18 12:13:48'
updated: '2019-11-18 12:28:28'
tags: [pandas, python]
permalink: /articles/2019/11/18/1574050428478.html
---
``
![](https://img.hacpai.com/bing/20190701.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

首先介绍dropna常用参数：

### DataFrame.dropna(axis=0, how='any', thresh=None, subset=None, inplace=False)
  
```bash
主要的2个参数axis和how：
#axis=0: 删除包含缺失值（NaN）的行
#axis=1: 删除包含缺失值（NaN）的列
# how='any': 要有缺失值（NaN）出现删除
# how='all': 所有的值都缺失（NaN）才删除

这两个要配合使用才好。

还有一个thresh参数
如果缺失值（NaN）的数量大于thresh，将删除

```
![image.png](https://img.hacpai.com/file/2019/11/image-6493efaa.png)


```bash
>>> import pandas as pd
>>> import numpy as np
>>> data = pd.DataFrame({'a': [1, 2, 4, np.nan,7, 9], 'b': ['a', 'b', np.nan, np.nan, 'd', 'e'], 'c': [np.nan, 0, 4, np.nan, np.nan, 5], 'd': [np.nan, np.nan, np.nan, np.nan, np.nan, np.nan]})
>>> data
     a    b    c   d
 1.0    a  NaN NaN
 2.0    b  0.0 NaN
 4.0  NaN  4.0 NaN
 NaN  NaN  NaN NaN
 7.0    d  NaN NaN
 9.0    e  5.0 NaN

```
**判断值value是否为NaN**

```bash
>>> np.isnan(value)    # return Ture or False #
>>> value is np.nan    # return Ture or False #
```

**删除NaN所在行**

 ```bash
'''use dropna(axis=0,how='all')'''
 >>> data.dropna(axis=0,how='all')
     a    b    c   d
 1.0    a  NaN NaN
 2.0    b  0.0 NaN
 4.0  NaN  4.0 NaN
 7.0    d  NaN NaN
 9.0    e  5.0 NaN
```

**删除表中含有任何NaN的行**

```bash
'''use dropna(axis=0,how='any')'''
>>> data.dropna(axis=0,how='any')
Empty DataFrame
Columns: [a, b, c, d]
Index: []
```

**删除表中全部为NaN的列**

```bash
'''use dropna(axis=1, how='all')'''
>>> data.dropna(axis=1, how='all')
     a    b    c
 1.0    a  NaN
 2.0    b  0.0
 4.0  NaN  4.0
 NaN  NaN  NaN
 7.0    d  NaN
 9.0    e  5.0
```

