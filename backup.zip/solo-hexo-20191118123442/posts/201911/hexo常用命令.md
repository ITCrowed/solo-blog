title: hexo 常用命令
date: '2019-11-03 00:15:21'
updated: '2019-11-03 00:15:21'
tags: [hexo, npm, 博客, blog]
permalink: /articles/2019/11/03/1572711321276.html
---
![](https://img.hacpai.com/bing/20190228.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

   Hexo 是一个快速、简洁且高效的博客框架。Hexo 使用 [Markdown](http://daringfireball.net/projects/markdown/)（或其他渲染引擎）解析文章，在几秒内，即可利用靓丽的主题生成静态网页。

## 安装/升级
安装 Hexo 相当简单，只需要先安装NodeJS 和 Git：

* [Node.js](http://nodejs.org/) (Node.js 版本需不低于 8.6，建议使用 Node.js 10.0 及以上版本)
* [Git](http://git-scm.com/)

如果您的电脑中已经安装上述程序，那么恭喜您！接下来只需要使用 npm 即可完成 Hexo 的安装。

### 首先安装hexo-cli脚手架 
```bash
  $ npm install -g hexo-cli
```
### 通过npm安装hexo
```bash
  npm install hexo -g #安装  
  npm update hexo -g #升级  
```
### 初始化并新建博客文章
```bash
  hexo init #初始化
  hexo n "我的博客" == hexo new "我的博客" #新建文章
  hexo n = hexo new
  hexo p == hexo publish
  hexo g == hexo generate#生成
  hexo s == hexo server #启动服务预览
  hexo d == hexo deploy#部署
```
## 监视文件变动
```bash
   hexo server #Hexo 会监视文件变动并自动更新，您无须重启服务器。
   hexo server -s #静态模式
   hexo server -p 5000 #更改端口
   hexo server -i 192.168.1.1 #自定义 IP

```
## 生成静态页面
```bash
   hexo generate #使用 Hexo 生成静态文件快速而且简单
   hexo generate --watch #监视文件变动

```

## 部署
```bash
   hexo generate --deploy
   hexo deploy --generate

```
可以缩写如下
```bash
   hexo deploy -g
   hexo server -g

```
## 创建新文章/预览/发布
```bash
   hexo new "postName" #新建文章
   hexo new page "pageName" #新建页面
   hexo generate #生成静态页面至public目录
   hexo server #开启预览访问端口（默认端口4000，'ctrl + c'关闭server）
   hexo deploy #将.deploy目录部署到GitHub
```

## 模版（Scaffold）
| 变量 |  描述 |
| --- |  --- |
| layout |  布局 |
| title |  标题 |
| date |  文件建立日期 |

```bash
 title: 使用Hexo搭建个人博客  
 layout: post  
 date: 2014-03-03 19:07:43  
 comments: true  
 categories: Blog  
 tags: [Hexo]  
 keywords: Hexo, Blog  
 description: 生命在于折腾
```

## 草稿
```bash
   hexo publish [layout] <title>
```

## 设置文章摘要
```
 <!--more-->
```
以上是**文章摘要**  `<!--more-->`以下是余下全文

