title: 宝塔面板（BT）安装命令
date: '2019-11-15 10:06:43'
updated: '2019-11-15 10:06:43'
tags: [centos, BT, 宝塔]
permalink: /articles/2019/11/15/1573783603170.html
---
![](https://img.hacpai.com/bing/20190119.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 安装BT（[宝塔面板](https://www.bt.cn/)）
打开你的shell连接到你的服务器后输入下面的代码
```bash
yum install -y wget && wget -O install.sh http://download.bt.cn/install/install_6.0.sh && sh install.sh
```
等待完成，出现下图后  
重要的事情说三遍！**赶紧复制这三行文本** **赶紧复制这三行文本** **赶紧复制这三行文本**
![47dqg2kiyo.png](https://img.hacpai.com/file/2019/11/47dqg2kiyo-0ddde212.png?imageView2/2/w/1280/format/jpg/interlace/1/q/100)

然后保存到一个不会被删的位置

然后通过浏览器打开第一行的地址，输入账号密码就来到了bt面板首页  
**选左边Nginx的那个**  
----等待安装
![HP1PASTBCSYVLYOO0W.png](https://img.hacpai.com/file/2019/11/HP1PASTBCSYVLYOO0W-dbbfbc88.png?imageView2/2/w/1280/format/jpg/interlace/1/q/100)
