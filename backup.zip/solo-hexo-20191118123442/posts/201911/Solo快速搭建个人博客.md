title: Solo快速搭建个人博客
date: '2019-11-15 14:05:44'
updated: '2019-11-15 14:05:44'
tags: [Java, Solo, Centos]
permalink: /articles/2019/11/15/1573797944826.html
---
![](https://img.hacpai.com/bing/20180211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 前言

  几天前作者直接把Servlet容器支持给移除了，意味着War包发布的形式不在可用。新的发布方式（在这里还是推崇Docker部署）如下：

* [下载](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fb3log%2Fsolo%2Freleases)最新的 zip 发布包后解压
* 更新配置文件，latke.props、local.props 等配置文件在解压的根目录下
* 启动新版
    * Windows: `java -cp "lib/*;." org.b3log.solo.Server`
    * Unix-like：`java -cp "lib/*:." org.b3log.solo.Server`

  `Solo的git地址是[github.com/b3log/solo](https://github.com/b3log/solo)。`

readme中有从零开始安装Solo博客的教程。里面讲的很详细了，基本都是按着命令清单输入的傻瓜式安装操作。
但是部署方式是通过**Docker部署**的，有些人可能不喜欢这种方式（因为学习Docker也需要时间），所以今天就讲一讲**War包部署**的方式（当然本人用的是Docker的方式去部署的，文章里的部署的方式可能比较简单）。

### 操作步骤

1. 首先去git上面clone下来代码，当然你也可以从版本的页面下载最新版本的war包，代码如下：

```
  wget https://github.com/b3log/solo/releases/download/v3.6.5/solo-v3.6.5.war
```

然后进入自己的服务器。首先假设用于部署的服务器为干净的（初始化过系统），因为不是很想讨论端口被占用如何去解决。

2. 安装Java环境，Solo作者推荐是JDK8（低版本好像不兼容），至于是openJdk还是sunJdk都没影响。代码如下：

```bash
  sudo yum -y install java-1.8.0-openjdk.x86_64
```

  查看Java版本 `java -version`，如下图所示，即安装成功:
![1.png](https://img.hacpai.com/file/2019/10/1-391ebade.png?imageView2/2/w/1280/format/jpg/interlace/1/q/100)

3. 安装Tomcat，直接去官网下载，当然你也可以执行下方的命令直接在服务器进行下载：

```
  wget http://mirrors.tuna.tsinghua.edu.cn/apache/tomcat/tomcat-8/v8.5.47/bin/apache-tomcat-8.5.47.tar.gz
```
    安装完成之后，使用命令`tar -zxvf apache-tomcat-8.5.47.tar.gz`来解压，解压完成后使用`cd`进入该目录，配置环境变量，执行以下命令`vim /etc/profile`。点击`i`（Ps.vim开启编辑模式）,输入如下代码：

`####tomcat#### 
CATALINA_BASE=/tomcat8.5.47
CATALINA_HOME=/tomcat8.5.47
TOMCAT_HOME=/tomcat8.5.47
export CATALINA_BASE CATALINA_HOME TOMCAT_HOME` 

   输入`:wq`，再输入`source /etc/profile`，此时tomcat环境变量配置完成。

4. 在mysql中执行下列命令创建指定字符集的数据库，其中solo为库名，启动项目时数据库中的表会自动创建。

```
  create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

5. 发布项目，上传war包至tomcat目录下的webapps文件夹内，然后cd切换至tomcat目录下的bin目录，执行命令`./startup.sh`，tomcat则开始启动。


### 常见问题
 **tomcat启动异常，error日志打印`Can't load the default skins...`，原因是war中没有初始皮肤文件，需要在git上面下载`webapp/skins`目录中的`Pinghsu`文件，然后放置到本地war包中的`webapps/skins`路径下，该文件为Solo的默认皮肤文件。如果没有的话tomcat启动时则会报错。**

**如果服务器是阿里云的请各位注意设置端口安全组，不然端口会无法访问，具体方法为登录阿里云账户，进入控制台，选中服务器，点击服务器名称，选择实例安全组。**

![image.png](https://img.hacpai.com/file/2019/10/image-d40290dc.png?imageView2/2/w/1280/format/jpg/interlace/1/q/100)

  **选择安全组列表，点击配置规则，点击添加安全组规则，填写规则方式如下图**  
![image.png](https://img.hacpai.com/file/2019/10/image-56a5407c.png?imageView2/2/w/1280/format/jpg/interlace/1/q/100)

### 后记

    后续应该会更新war包部署后使用nginx代理实现https等操作.
