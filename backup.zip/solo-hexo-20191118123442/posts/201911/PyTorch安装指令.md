title: PyTorch安装指令
date: '2019-11-15 14:31:24'
updated: '2019-11-15 14:31:37'
tags: [PyTorch]
permalink: /articles/2019/11/15/1573799484289.html
---
![](https://img.hacpai.com/bing/20190325.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


# PyTorch安装指令
请先安装Anaconda和CUDA 10.0。

* 配置国内源

## 配置国内源，方便安装Numpy,Matplotlib等
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main/
## 配置国内源，安装PyTorch用
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/pytorch/
## 显示源地址
conda config --set show_channel_urls yes

* 安装PyTorch

## 安装PyTorch，要使用国内源请去掉-c pytorch这个参数！！
conda install pytorch torchvision cudatoolkit=10.0

* 安装常用库

pip install numpy matplotlib pillow pandas
