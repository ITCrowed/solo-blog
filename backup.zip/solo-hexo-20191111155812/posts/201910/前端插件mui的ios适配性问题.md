title: 前端插件 mui 的 ios 适配性问题
date: '2019-10-30 16:36:17'
updated: '2019-11-03 11:55:31'
tags: [前端, ios兼容性]
permalink: /articles/2019/10/30/1572424576897.html
---
![](https://img.hacpai.com/bing/20171122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

由于项目前端 h5 页面使用了 mui 插件，`其中选择框插件在 iOS 中第一项不能选中`，在百度中试验了各种方法，发现需要在所有选项之前要加一个`<option style="display:none" value="" disabled>请选择</option>`

修改后的代码是：
```bash
	<label>紧急状态</label>
	<div class=" select" style="display: flex">
		<select name="status" v-model="task.urgStatus" class="mui-h5 per_select">
			<option style="display:none" value="" disabled>请选择</option>
			<option  value="1">一般</option>
			<option value="2">重要</option>
			<option value="3">紧急</option>
		</select>
		<i class="mui-icon mui-icon-arrowdown" style="color: #999999;font-size: 22px;"></i>
	</div>
```
兼容性

