title: pandas的concat函数和append方法
date: '2019-11-14 15:40:52'
updated: '2019-11-14 15:40:52'
tags: [待分类]
permalink: /articles/2019/11/14/1573717252469.html
---
![](https://img.hacpai.com/bing/20181130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## [pandas的concat函数和append方法]()
```python
pd.concat(objs, axis=0, join='outer', join_axes=None, ignore_index=False,keys=None, levels=None, names=None, verify_integrity=False)
```
**objs**:   series，dataframe或者是panel构成的序列list  
**axis**：需要合并链接的轴,0是行,1是列   
**join**： 连接的方式 :inner,outer
1.相同字段的表首尾相接

![](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919112139454-221266740.png)

```
import pandas
pd.concat([df1,df2,df3])
```
相接的时候在加上一个层次的keys来识别数据源自于哪张表，可以增加keys参数:

```
import pandas
pd.concat([df1,df2,df3],keys=["df1","df2","df3"])
```

![null](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919112522814-995727963.png)

2.行对齐进行拼接

![](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919112645419-1469619866.png)
```
pd.concat([df1,df4],axis=1)
```
3.join属性：’inner’是两表的交集，“outer”是两表的并集
![null](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919113007319-2122056683.png)

```
pd.concat([df1, df4], axis=1, join='inner')
```
4.join_axes：可以指定根据那个轴来对齐数据 

![](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919113158563-1534688022.png)

```
pd.concat([df1, df4], axis=1, join_axes=[df1.index])
```
 4.无视index：两个表的index都没有实际含义，使用ignore_index参数，合并的两个表就根据列字段对齐，然后合并并得到新的index

![](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919113442124-1685528993.png)

5.append：append是series和dataframe的方法，使用它就是默认沿着（axis = 0）列进行拼接

![](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919113907800-1993586207.png)
```
df1.append(df2)
```
 6.Dataframe中加入新的行

![](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919114023079-1760154918.png)

7.表格列字段不同的表合并

![](https://img2018.cnblogs.com/blog/1473673/201809/1473673-20180919114146135-105463265.png)
```
df1.append(dicts, ignore_index=True)
```

---
原文链接：https://www.cnblogs.com/wzdLY/p/9673767.html
